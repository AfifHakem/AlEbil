'use client';
import { useEffect, useState } from 'react';
export default function QuizUI({ mod, level }) {
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);

  useEffect(() => {
    import(`../data/${mod}-level-${level}.json`).then(setQuestions);
    const bgm = new Audio('/sounds/bg-music.mp3');
    bgm.loop = true;
    bgm.volume = 0.2;
    bgm.play();
  }, [mod, level]);

  const checkAnswer = (ans, correct) => {
    const audio = new Audio(ans === correct ? '/sounds/correct.mp3' : '/sounds/wrong.mp3');
    audio.play();
    if (ans === correct) setScore(score + 1);
    setCurrent(current + 1);
  };

  if (!questions.length) return <p>Loading...</p>;
  if (current >= questions.length) return <p>Markah: {score} / {questions.length}</p>;

  const q = questions[current];
  return (
    <div>
      <h2>{q.q}</h2>
      {q.options.map(opt => (
        <button key={opt} onClick={() => checkAnswer(opt, q.answer)}>{opt}</button>
      ))}
    </div>
  );
}