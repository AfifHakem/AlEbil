import QuizUI from '../../../../../../components/QuizUI';
export default function LevelPage({ params }) {
  const { mod, level } = params;
  return <QuizUI mod={mod} level={level} />;
}