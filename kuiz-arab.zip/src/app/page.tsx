import Link from 'next/link';
export default function Home() {
  const mods = ['mudah', 'sederhana', 'susah'];
  return (
    <main style={{ backgroundImage: "url('/images/desert-bg.jpg')" }}>
      <h1>Kuiz Arabic – Pilih Mod</h1>
      {mods.map(m => (
        <Link key={m} href={`/mod/${m}/level/1`}>
          <button className="mod-btn">{m.toUpperCase()}</button>
        </Link>
      ))}
    </main>
  );
}